var searchData=
[
  ['validacontatto_0',['validaContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a3d9f6407f8bf925543956185bbb88a76',1,'it::unisa::diem::sen::api::Contatto']]],
  ['validaemail_1',['validaEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ab912e94480c3a9b51701a03b6a57c9b8',1,'it::unisa::diem::sen::api::Contatto']]],
  ['validanumtelefono_2',['validaNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ab18f3e7a94b2092eb62face1baf03ffc',1,'it::unisa::diem::sen::api::Contatto']]],
  ['validatore_3',['Validatore',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore.html',1,'it::unisa::diem::sen::api']]]
];
