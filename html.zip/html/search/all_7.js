var searchData=
[
  ['salvarubrica_0',['salvaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#abb73fd08fd3c6e030df9c48030051bfd',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['setcognome_1',['setCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a338af475e8ff50f4244cabbbed37c576',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setemail_2',['setEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#abc9fdbcb407b6090243f512d44de72d6',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnome_3',['setNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ade22307879c8206e4bf953ff2c5e0df9',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnumtelefono_4',['setNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#adbc584b24a78ac4a076c89abb0771337',1,'it::unisa::diem::sen::api::Contatto']]]
];
