var searchData=
[
  ['rubrica_0',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html',1,'it::unisa::diem::sen::api']]]
];
