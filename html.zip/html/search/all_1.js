var searchData=
[
  ['caricarubrica_0',['caricaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a57183b6c39be6724ca49d204da4d5c1d',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['cercacontatto_1',['cercaContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#afc3a3d58ab09cc196964e976f26f76c4',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['compareto_2',['compareTo',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a3e1694f9d3554077ab24f3774c50e4fc',1,'it::unisa::diem::sen::api::Contatto']]],
  ['contatto_3',['Contatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html',1,'it.unisa.diem.sen.api.Contatto'],['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a2845196b0bdcec0ebb988d3a13d2129e',1,'it.unisa.diem.sen.api.Contatto.Contatto()']]]
];
