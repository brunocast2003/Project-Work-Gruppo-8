var searchData=
[
  ['rimuovicontatto_0',['rimuoviContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#aa47320901997fed95f5ef780cb6aef1e',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['rubrica_1',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html',1,'it.unisa.diem.sen.api.Rubrica&lt; Contatto &gt;'],['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#abfc670ce024c79d98f818613ab445113',1,'it.unisa.diem.sen.api.Rubrica.Rubrica()']]]
];
