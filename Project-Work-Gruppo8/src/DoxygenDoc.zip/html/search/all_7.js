var searchData=
[
  ['initialize_0',['initialize',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a01414ea364d246cb050bc1ceb6f40d3f',1,'it.unisa.diem.sen.gui.ContattoViewController.initialize()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a2411c1c20ac42a55db1161320a8758d7',1,'it.unisa.diem.sen.gui.RubricaViewController.initialize()']]]
];
