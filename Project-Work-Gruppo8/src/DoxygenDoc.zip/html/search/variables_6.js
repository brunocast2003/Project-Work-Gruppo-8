var searchData=
[
  ['salvarubrica_0',['salvaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a98f5e674f51c2004fba6b03cea48aa8a',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['stage_1',['stage',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ac8f4d78c05d653829d24023a9a6941fd',1,'it.unisa.diem.sen.gui.ContattoViewController.stage'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a8b13747124e3e5ab7e8d494dcac5d5af',1,'it.unisa.diem.sen.gui.RubricaViewController.stage']]]
];
