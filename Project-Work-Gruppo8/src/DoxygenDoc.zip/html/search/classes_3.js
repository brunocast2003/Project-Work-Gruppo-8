var searchData=
[
  ['main_0',['Main',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_main.html',1,'it::unisa::diem::sen::gui']]]
];
