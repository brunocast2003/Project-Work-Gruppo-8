var searchData=
[
  ['lblcognome_0',['lblCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a317e302dfbb588fa7c972feb3b85ae1a',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lblemail1_1',['lblEmail1',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ab1928dcfa516efc4d1a3aa915dadb5c7',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lblemail2_2',['lblEmail2',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a8d619a740b9f75d772b4996834cdf733',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lblemail3_3',['lblEmail3',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#af32f37dd9061c372ba2777170fdfb05b',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lblnome_4',['lblNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a3e5357bf9374a6305976a24f22e21a90',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lbltelefono1_5',['lblTelefono1',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ad996126de6ad71f17e1686c93dd02209',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lbltelefono2_6',['lblTelefono2',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a517db3de8c68ec5a8dfee3cdff4b350e',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['lbltelefono3_7',['lblTelefono3',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a2a5038101bd8f067f8e2e7f2b0863440',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['listacontatti_8',['listaContatti',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a1875b201236f527d051631fbdadfd367',1,'it::unisa::diem::sen::gui::RubricaViewController']]]
];
