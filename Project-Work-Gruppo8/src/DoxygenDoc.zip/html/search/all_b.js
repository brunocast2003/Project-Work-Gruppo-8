var searchData=
[
  ['ordinarubrica_0',['ordinaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a87fd8c698f12c69cdde7734a15d1c19b',1,'it::unisa::diem::sen::api::Rubrica']]]
];
