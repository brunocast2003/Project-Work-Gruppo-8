var searchData=
[
  ['aggiornalistacontatti_0',['aggiornaListaContatti',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#aa1c191218f0c41ecc349c1b49a7c1de6',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['aggiungicontatto_1',['aggiungiContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a1e1ab185408f95129f5aa82f6381e1ca',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['aggiungiemail_2',['aggiungiEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a0e0bb781fe7a6be38723ffe1ef331adf',1,'it::unisa::diem::sen::api::Contatto']]],
  ['aggiunginumerotelefono_3',['aggiungiNumeroTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ac6f88d0a82165ff4c95359a16bd041b5',1,'it::unisa::diem::sen::api::Contatto']]],
  ['annulla_4',['annulla',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a1cd8435b20941e05ff5967901de6eb86',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
