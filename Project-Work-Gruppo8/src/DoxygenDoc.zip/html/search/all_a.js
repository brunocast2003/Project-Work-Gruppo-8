var searchData=
[
  ['nome_0',['nome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#aadba9a0cb29c564fb0d1cf83bad0174e',1,'it::unisa::diem::sen::api::Contatto']]],
  ['numtelefono_1',['numTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#aa319de8d5de03d2ebacf5785dd477052',1,'it::unisa::diem::sen::api::Contatto']]]
];
