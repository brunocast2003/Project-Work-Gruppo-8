var searchData=
[
  ['caricarubrica_0',['caricaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#abd1ce192a9d58e973a206047852bcef3',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['cognome_1',['cognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a01f6fccb7e13fcc164d50573c8fb89a7',1,'it::unisa::diem::sen::api::Contatto']]],
  ['contatti_2',['contatti',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a481682f85e75505d7573898dff0c676c',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['contatto_3',['contatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a3bc0960c2f14fe2bc30a145a67f08051',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
