var searchData=
[
  ['gestorecontatti_0',['GestoreContatti',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_gestore_contatti.html',1,'it::unisa::diem::sen::api']]],
  ['gestorecontatti_3c_20contatto_20_3e_1',['GestoreContatti&lt; Contatto &gt;',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_gestore_contatti.html',1,'it::unisa::diem::sen::api']]],
  ['gestorecontatti_3c_20it_3a_3aunisa_3a_3adiem_3a_3asen_3a_3aapi_3a_3acontatto_20_3e_2',['GestoreContatti&lt; it::unisa::diem::sen::api::Contatto &gt;',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_gestore_contatti.html',1,'it::unisa::diem::sen::api']]]
];
