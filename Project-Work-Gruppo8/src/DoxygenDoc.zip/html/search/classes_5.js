var searchData=
[
  ['validatore_0',['Validatore',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore.html',1,'it::unisa::diem::sen::api']]],
  ['validatorestandard_1',['ValidatoreStandard',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html',1,'it::unisa::diem::sen::api']]],
  ['validatorestandardtest_2',['ValidatoreStandardTest',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard_test.html',1,'it::unisa::diem::sen::api']]]
];
