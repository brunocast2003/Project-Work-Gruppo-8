var searchData=
[
  ['getcognome_0',['getCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a73545d870b1449e68c0560beb31f8ecc',1,'it::unisa::diem::sen::api::Contatto']]],
  ['getemail_1',['getEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ac501d3825e0aac8f077811bdfc4acb64',1,'it::unisa::diem::sen::api::Contatto']]],
  ['getnome_2',['getNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#acc8defc16db90111e539c72079080875',1,'it::unisa::diem::sen::api::Contatto']]],
  ['getnumtelefono_3',['getNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a79059e8e0da78a3c73239d19a19ce3a4',1,'it::unisa::diem::sen::api::Contatto']]],
  ['getstage_4',['getStage',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a32dfe5b15816abca501796a73239e0d1',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['gettutticontatti_5',['getTuttiContatti',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#ab8f2a99dca05c7c55eb5cbb39a3c3ac7',1,'it::unisa::diem::sen::api::Rubrica']]]
];
