var searchData=
[
  ['validatore_0',['validatore',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a46c4ad40249176cc260bb16705ec6e03',1,'it::unisa::diem::sen::api::Contatto']]]
];
