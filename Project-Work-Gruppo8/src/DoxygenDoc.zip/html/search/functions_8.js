var searchData=
[
  ['rimuovicontatto_0',['rimuoviContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a18a907c3007ecfec3c91e1e1a4ecb567',1,'it.unisa.diem.sen.api.Rubrica.rimuoviContatto()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ae224fac17ef299e31e86bda38c07f6ed',1,'it.unisa.diem.sen.gui.ContattoViewController.rimuoviContatto()']]],
  ['rubrica_1',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#af359d53c2576d6d83a8468c914bfabca',1,'it::unisa::diem::sen::api::Rubrica']]]
];
