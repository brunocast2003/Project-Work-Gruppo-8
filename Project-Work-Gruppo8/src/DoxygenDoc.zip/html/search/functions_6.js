var searchData=
[
  ['main_0',['main',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_main.html#a96be61160536da62a8c974d1db7a3b3d',1,'it::unisa::diem::sen::gui::Main']]]
];
