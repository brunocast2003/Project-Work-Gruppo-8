var searchData=
[
  ['fileio_0',['FileIO',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_file_i_o.html',1,'it::unisa::diem::sen::api']]]
];
