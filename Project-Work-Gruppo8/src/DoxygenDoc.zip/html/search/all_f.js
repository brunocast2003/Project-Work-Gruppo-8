var searchData=
[
  ['validacognome_0',['validaCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html#a256af9c3b5bcbdb5aa4269dd1aecca98',1,'it::unisa::diem::sen::api::ValidatoreStandard']]],
  ['validaemail_1',['validaEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html#adb5beab30ffad08202d7c3d9cf9ef847',1,'it::unisa::diem::sen::api::ValidatoreStandard']]],
  ['validanome_2',['validaNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html#aafe61152b32852b57938603510fae1cf',1,'it::unisa::diem::sen::api::ValidatoreStandard']]],
  ['validanumtelefono_3',['validaNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html#a9745fc8527cd2d12dbfcb1f5a411a0af',1,'it::unisa::diem::sen::api::ValidatoreStandard']]],
  ['validatore_4',['Validatore',['../interfaceit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore.html',1,'it::unisa::diem::sen::api']]],
  ['validatore_5',['validatore',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a46c4ad40249176cc260bb16705ec6e03',1,'it::unisa::diem::sen::api::Contatto']]],
  ['validatorestandard_6',['ValidatoreStandard',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard.html',1,'it::unisa::diem::sen::api']]],
  ['validatorestandardtest_7',['ValidatoreStandardTest',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_validatore_standard_test.html',1,'it::unisa::diem::sen::api']]]
];
