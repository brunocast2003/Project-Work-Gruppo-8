var searchData=
[
  ['rubrica_0',['rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a4cd32a4bb1c2d3d4106c7c08db92b0c6',1,'it.unisa.diem.sen.gui.ContattoViewController.rubrica'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a9e5a7e284234f6540ecfc1eef2c259fa',1,'it.unisa.diem.sen.gui.RubricaViewController.rubrica']]],
  ['rubricaviewcontroller_1',['rubricaViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a55b41258d275832e29de4638850c9a94',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
