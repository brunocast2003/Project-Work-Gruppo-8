var searchData=
[
  ['tostring_0',['toString',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a687bd80efc5f449a2c76438fb617530e',1,'it::unisa::diem::sen::api::Contatto']]]
];
