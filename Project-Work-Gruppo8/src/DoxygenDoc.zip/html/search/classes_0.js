var searchData=
[
  ['contatto_0',['Contatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html',1,'it::unisa::diem::sen::api']]],
  ['contattotest_1',['ContattoTest',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto_test.html',1,'it::unisa::diem::sen::api']]],
  ['contattoviewcontroller_2',['ContattoViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html',1,'it::unisa::diem::sen::gui']]]
];
