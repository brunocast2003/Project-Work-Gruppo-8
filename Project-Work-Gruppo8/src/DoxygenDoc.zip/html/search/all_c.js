var searchData=
[
  ['rimuovicontatto_0',['rimuoviContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a18a907c3007ecfec3c91e1e1a4ecb567',1,'it.unisa.diem.sen.api.Rubrica.rimuoviContatto()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ae224fac17ef299e31e86bda38c07f6ed',1,'it.unisa.diem.sen.gui.ContattoViewController.rimuoviContatto()']]],
  ['rubrica_1',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html',1,'it.unisa.diem.sen.api.Rubrica'],['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#af359d53c2576d6d83a8468c914bfabca',1,'it.unisa.diem.sen.api.Rubrica.Rubrica()']]],
  ['rubrica_2',['rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a4cd32a4bb1c2d3d4106c7c08db92b0c6',1,'it.unisa.diem.sen.gui.ContattoViewController.rubrica'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a9e5a7e284234f6540ecfc1eef2c259fa',1,'it.unisa.diem.sen.gui.RubricaViewController.rubrica']]],
  ['rubrica_2ejava_3',['Rubrica.java',['../_rubrica_8java.html',1,'']]],
  ['rubricatest_4',['RubricaTest',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica_test.html',1,'it::unisa::diem::sen::api']]],
  ['rubricaviewcontroller_5',['RubricaViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html',1,'it::unisa::diem::sen::gui']]],
  ['rubricaviewcontroller_6',['rubricaViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a55b41258d275832e29de4638850c9a94',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
