var searchData=
[
  ['salvacontatto_0',['salvaContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a598fb640905738fcd4bb440f54aad800',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['salvarubrica_1',['salvaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a89ea6ed9e9533d50837b36510805283b',1,'it.unisa.diem.sen.api.Rubrica.salvaRubrica()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a909955d2951a02d7f239a658b63d7538',1,'it.unisa.diem.sen.gui.RubricaViewController.salvaRubrica()']]],
  ['setcognome_2',['setCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a338af475e8ff50f4244cabbbed37c576',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setemail_3',['setEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a48de57373397fb0eac899f4fab328277',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnome_4',['setNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ade22307879c8206e4bf953ff2c5e0df9',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnumtelefono_5',['setNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a33ff8df5079041acb6192baa11f5caf1',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setstage_6',['setStage',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a94221f87c1c601675e567e474bf2e61c',1,'it.unisa.diem.sen.gui.ContattoViewController.setStage()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a2f2906d776cfba304f26ecb4ad84dca1',1,'it.unisa.diem.sen.gui.RubricaViewController.setStage()']]],
  ['start_7',['start',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_main.html#a8dd96bfb107496de7a5a33cc7031a696',1,'it::unisa::diem::sen::gui::Main']]],
  ['starter_8',['starter',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a06799c9f1825875defed824007819dcb',1,'it.unisa.diem.sen.gui.ContattoViewController.starter()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#acc5d0cb2d62372d8afa828c2c479aff3',1,'it.unisa.diem.sen.gui.RubricaViewController.starter(GestoreContatti&lt; Contatto &gt; rubrica)']]],
  ['switchcontattoview_9',['switchContattoView',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a9b6072fa5488a2022b10c73d89d7a064',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['switchrubricaview_10',['switchRubricaView',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ace03c8e2c92e5d8e563208cb068cd3bb',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
