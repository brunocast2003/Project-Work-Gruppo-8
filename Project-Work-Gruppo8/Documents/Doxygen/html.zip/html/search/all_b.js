var searchData=
[
  ['rimuovicontatto_0',['rimuoviContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#aa47320901997fed95f5ef780cb6aef1e',1,'it.unisa.diem.sen.api.Rubrica.rimuoviContatto()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#ae224fac17ef299e31e86bda38c07f6ed',1,'it.unisa.diem.sen.gui.ContattoViewController.rimuoviContatto()']]],
  ['rubrica_1',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html',1,'it.unisa.diem.sen.api.Rubrica&lt; Contatto &gt;'],['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#abfc670ce024c79d98f818613ab445113',1,'it.unisa.diem.sen.api.Rubrica.Rubrica()']]],
  ['rubrica_2ejava_2',['Rubrica.java',['../_rubrica_8java.html',1,'']]],
  ['rubricaviewcontroller_3',['RubricaViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html',1,'it::unisa::diem::sen::gui']]]
];
