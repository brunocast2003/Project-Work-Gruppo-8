var searchData=
[
  ['barraricerca_0',['barraRicerca',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a0de3984ff3b30d48a4ab4a98e940e3ed',1,'it::unisa::diem::sen::gui::RubricaViewController']]],
  ['btnaggiungicontatto_1',['btnAggiungiContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a0658916ece73e79f77a33b316b37f05c',1,'it::unisa::diem::sen::gui::RubricaViewController']]]
];
