var searchData=
[
  ['ordinarubrica_0',['ordinaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a454686a17337e42963e9405b01a413e6',1,'it::unisa::diem::sen::api::Rubrica']]]
];
