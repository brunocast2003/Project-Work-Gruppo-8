var searchData=
[
  ['main_0',['main',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_main.html#a70478e9b496ea232a43a9178ed60bb3b',1,'it::unisa::diem::sen::api::Main']]],
  ['modificacontatto_1',['modificaContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a90d4d2f50ac26c0e004117c7d165f949',1,'it::unisa::diem::sen::api::Rubrica']]]
];
