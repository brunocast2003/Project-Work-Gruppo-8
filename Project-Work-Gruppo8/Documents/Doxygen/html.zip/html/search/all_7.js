var searchData=
[
  ['listacontatti_0',['listaContatti',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#aa4a3a15d9a93fb638e9438e81e2063ee',1,'it::unisa::diem::sen::gui::RubricaViewController']]]
];
