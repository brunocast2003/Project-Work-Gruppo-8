var searchData=
[
  ['salvarubrica_0',['salvaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a98f5e674f51c2004fba6b03cea48aa8a',1,'it::unisa::diem::sen::gui::RubricaViewController']]]
];
