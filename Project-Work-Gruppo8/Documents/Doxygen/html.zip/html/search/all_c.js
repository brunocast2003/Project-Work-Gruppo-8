var searchData=
[
  ['salvacontatto_0',['salvaContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a598fb640905738fcd4bb440f54aad800',1,'it::unisa::diem::sen::gui::ContattoViewController']]],
  ['salvarubrica_1',['salvaRubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a98f5e674f51c2004fba6b03cea48aa8a',1,'it.unisa.diem.sen.gui.RubricaViewController.salvaRubrica'],['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#abb73fd08fd3c6e030df9c48030051bfd',1,'it.unisa.diem.sen.api.Rubrica.salvaRubrica()'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a909955d2951a02d7f239a658b63d7538',1,'it.unisa.diem.sen.gui.RubricaViewController.salvaRubrica()']]],
  ['setcognome_2',['setCognome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a338af475e8ff50f4244cabbbed37c576',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setemail_3',['setEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#abc9fdbcb407b6090243f512d44de72d6',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnome_4',['setNome',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ade22307879c8206e4bf953ff2c5e0df9',1,'it::unisa::diem::sen::api::Contatto']]],
  ['setnumtelefono_5',['setNumTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#adbc584b24a78ac4a076c89abb0771337',1,'it::unisa::diem::sen::api::Contatto']]],
  ['switchcontattoview_6',['switchContattoView',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a80bdd46389c257cdcac86566ad428839',1,'it.unisa.diem.sen.gui.RubricaViewController.switchContattoView(MouseEvent event)'],['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html#a9f80e382cc0e6a7b27c5b9381d938ed3',1,'it.unisa.diem.sen.gui.RubricaViewController.switchContattoView(ActionEvent event)']]],
  ['switchrubricaview_7',['switchRubricaView',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#adc8528c0fb91422add3a90658eac8426',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
