var searchData=
[
  ['aggiungicontatto_0',['aggiungiContatto',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html#a8c807026044632cc193eda6d967fa11c',1,'it::unisa::diem::sen::api::Rubrica']]],
  ['aggiungiemail_1',['aggiungiEmail',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#a0e0bb781fe7a6be38723ffe1ef331adf',1,'it::unisa::diem::sen::api::Contatto']]],
  ['aggiunginumerotelefono_2',['aggiungiNumeroTelefono',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_contatto.html#ac6f88d0a82165ff4c95359a16bd041b5',1,'it::unisa::diem::sen::api::Contatto']]],
  ['annulla_3',['annulla',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_contatto_view_controller.html#a1cd8435b20941e05ff5967901de6eb86',1,'it::unisa::diem::sen::gui::ContattoViewController']]]
];
