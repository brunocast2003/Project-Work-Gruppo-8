var searchData=
[
  ['rubrica_0',['Rubrica',['../classit_1_1unisa_1_1diem_1_1sen_1_1api_1_1_rubrica.html',1,'it::unisa::diem::sen::api']]],
  ['rubricaviewcontroller_1',['RubricaViewController',['../classit_1_1unisa_1_1diem_1_1sen_1_1gui_1_1_rubrica_view_controller.html',1,'it::unisa::diem::sen::gui']]]
];
